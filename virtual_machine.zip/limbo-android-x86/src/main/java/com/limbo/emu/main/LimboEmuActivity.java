package com.virtual.emu.main;

import android.os.Bundle;

import com.max2idea.android.limbo.log.Logger;
import com.max2idea.android.limbo.main.Config;
import com.max2idea.android.limbo.main.LimboActivity;
import com.max2idea.android.limbo.links.LinksManager;
import com.max2idea.android.limbo.main.LimboApplication;

public class LimboEmuActivity extends LimboActivity {

    @Override
    public void onCreate(Bundle bundle) {
        // 1. Configuración de Arquitectura
        LimboApplication.arch = Config.Arch.x86_64;
        Config.clientClass = this.getClass();
        
        // 2. Configuración de KVM (Kernel-based Virtual Machine)
        Config.enableKVM = true;

        // 3. Lógica para MTTCG (Multi-Threaded TCG)
        // Solo para hosts de 64 bits y si se cumplen las condiciones de QEMU
        if(LimboApplication.isHost64Bit() && Config.enableMTTCG) {
            Config.enableMTTCG = true;
        } else {
            Config.enableMTTCG = false;
        }

        // --- SECCIÓN DE ENLACES ELIMINADA ---
        // Aquí es donde estaban las URLs de las imágenes ISO. 
        // Ahora la lista de imágenes descargables estará vacía.

        super.onCreate(bundle);

        // 4. Configuración del Log
        // TODO: Recuerda cambiar esto si necesitas guardar el log en una ubicación accesible por el usuario
        Logger.setupLogFile("/limbo/limbo-x86-log.txt");
    }

    protected void loadQEMULib() {
        try {
            // Intenta cargar la librería de 64 bits
            System.loadLibrary("qemu-system-x86_64");
            
        } catch (Error ex) {
            // Si falla, carga la de 32 bits
            System.loadLibrary("qemu-system-i386");
        }
    }
}