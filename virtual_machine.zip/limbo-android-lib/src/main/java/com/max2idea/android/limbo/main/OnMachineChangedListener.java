package com.max2idea.android.limbo.main;

import com.max2idea.android.limbo.machine.Machine;

public interface OnMachineChangedListener {
    void onMachineChanged(Machine machine, Object data);
}