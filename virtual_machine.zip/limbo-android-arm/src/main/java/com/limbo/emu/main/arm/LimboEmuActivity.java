package com.limbo.emu.main.arm;

import android.os.Bundle;
import android.os.Environment; // Necesario para el almacenamiento externo
import java.io.File; // Necesario para gestionar rutas de archivos

import com.max2idea.android.limbo.log.Logger;
import com.max2idea.android.limbo.main.Config;
import com.max2idea.android.limbo.main.LimboActivity;
import com.max2idea.android.limbo.main.LimboApplication;
// Se ha eliminado la importación de LinksManager porque ya no se usa.

public class LimboEmuActivity extends LimboActivity {

    @Override // Buena práctica para indicar que se anula un método
    public void onCreate(Bundle bundle){
        // 1. CONFIGURACIÓN DE ARQUITECTURA (ENFOCADO EN ARM64)
        LimboApplication.arch = Config.Arch.arm64;
        Config.clientClass = this.getClass();

        // 2. CONFIGURACIÓN DE CARACTERÍSTICAS
        Config.enableKVM = true; // KVM para virtualización (si el host lo soporta)
        Config.enableEmulatedFloppy = false; // Floppy generalmente no es necesario en ARM
        Config.enableEmulatedSDCard = true; // Útil para la transferencia de archivos en emulación ARM

        // 3. LÓGICA MTTCG (OPTIMIZACIÓN DE RENDIMIENTO)
        // Ya que el host es 64-bit, habilitamos MTTCG para mejor rendimiento multihilo.
        // Se asume la existencia de QEMU arm-softmmu 2.9.1+ compilado para 64-bit.
        // Si el host es 64-bit y Limbo Application soporta MTTCG, lo activamos.
        // La condición original era redundante, la simplificamos para ser más clara.
        if (LimboApplication.isHost64Bit()) {
            // El host es 64-bit, podemos usar MTTCG (Multi-Threaded TCG)
            Config.enableMTTCG = true;
        } else {
            // En caso contrario (aunque el host es 64-bit según el requerimiento,
            // mantenemos la lógica de seguridad para otros casos).
            Config.enableMTTCG = false;
        }

        // 4. CONFIGURACIÓN DE RUTA DE MÁQUINAS VIRTUALES ARM
        Config.machineFolder = Config.machineFolder + "other/arm_machines/";

        // 5. ELIMINACIÓN DE ENLACE ROTO
        // *** SE HA ELIMINADO LA CONFIGURACIÓN DE OSImages (DebianArmLinux) ***

        super.onCreate(bundle);

        // 6. RESOLUCIÓN DEL TODO (CONFIGURACIÓN DEL ARCHIVO DE REGISTRO)
        // Usamos la ruta de almacenamiento externo pública de la aplicación para que el usuario pueda acceder al registro.
        // Esto resuelve el TODO original.
        File logFileDir = new File(Environment.getExternalStorageDirectory(), "LimboEmu");
        // Asegúrate de que el directorio exista
        if (!logFileDir.exists()) {
            logFileDir.mkdirs();
        }
        // Configura el archivo de registro dentro del directorio accesible
        Logger.setupLogFile(logFileDir.getAbsolutePath() + "/limbo-arm-log.txt");
    }

    protected void loadQEMULib(){
        // Al ser un host 64-bit, intentamos cargar primero la librería más optimizada.
        try {
            System.loadLibrary("qemu-system-aarch64");
            // Si funciona, hemos cargado la versión optimizada para 64 bits (AArch64)
        } catch (Error ex) {
            // Si falla (por ejemplo, si solo existe la versión ARM de 32 bits),
            // intentamos cargar la versión base (ARM/AArch32).
            System.loadLibrary("qemu-system-arm");
        }
    }
}